<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=school_db',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.gmail.com',
                'username' => 'anasshafqat02@gmail.com',
                'password' => 'anas12345',
                'port' => '587',
                'encryption' => 'tls',
                ],
            'viewPath' => '@common/mail',
        ],
    ],
];